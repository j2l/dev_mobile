
package com.metiersdb.data;



/**
 *  metiersDB.Sous
 *  09/18/2012 17:49:53
 * 
 */
public class Sous {

    private SousId id;

    public SousId getId() {
        return id;
    }

    public void setId(SousId id) {
        this.id = id;
    }

}
