
package com.metiersdb.data;



/**
 *  metiersDB.Sinistres
 *  09/18/2012 17:49:53
 * 
 */
public class Sinistres {

    private SinistresId id;

    public SinistresId getId() {
        return id;
    }

    public void setId(SinistresId id) {
        this.id = id;
    }

}
