
package com.metiersdb.data;



/**
 *  metiersDB.Cotations
 *  09/18/2012 17:49:53
 * 
 */
public class Cotations {

    private CotationsId id;

    public CotationsId getId() {
        return id;
    }

    public void setId(CotationsId id) {
        this.id = id;
    }

}
