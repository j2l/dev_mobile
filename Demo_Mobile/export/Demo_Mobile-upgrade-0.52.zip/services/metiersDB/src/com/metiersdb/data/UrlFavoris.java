
package com.metiersdb.data;



/**
 *  metiersDB.UrlFavoris
 *  09/18/2012 17:49:53
 * 
 */
public class UrlFavoris {

    private Long favId;
    private String favBadge;
    private String favDossier;
    private String favNom;
    private String favUrl;

    public Long getFavId() {
        return favId;
    }

    public void setFavId(Long favId) {
        this.favId = favId;
    }

    public String getFavBadge() {
        return favBadge;
    }

    public void setFavBadge(String favBadge) {
        this.favBadge = favBadge;
    }

    public String getFavDossier() {
        return favDossier;
    }

    public void setFavDossier(String favDossier) {
        this.favDossier = favDossier;
    }

    public String getFavNom() {
        return favNom;
    }

    public void setFavNom(String favNom) {
        this.favNom = favNom;
    }

    public String getFavUrl() {
        return favUrl;
    }

    public void setFavUrl(String favUrl) {
        this.favUrl = favUrl;
    }

}
