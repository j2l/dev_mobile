
package com.metiersdb.data;



/**
 *  metiersDB.UserDroit
 *  09/18/2012 17:49:53
 * 
 */
public class UserDroit {

    private UserDroitId id;

    public UserDroitId getId() {
        return id;
    }

    public void setId(UserDroitId id) {
        this.id = id;
    }

}
