
package com.metiersdb.data;



/**
 *  metiersDB.Demo
 *  09/18/2012 17:49:53
 * 
 */
public class Demo {

    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

}
