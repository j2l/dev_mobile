
package com.metiersdb.data;



/**
 *  metiersDB.RefReport
 *  09/18/2012 17:49:53
 * 
 */
public class RefReport {

    private String codeReport;
    private String nomReport;
    private String descriptionReport;
    private String urlReport;

    public String getCodeReport() {
        return codeReport;
    }

    public void setCodeReport(String codeReport) {
        this.codeReport = codeReport;
    }

    public String getNomReport() {
        return nomReport;
    }

    public void setNomReport(String nomReport) {
        this.nomReport = nomReport;
    }

    public String getDescriptionReport() {
        return descriptionReport;
    }

    public void setDescriptionReport(String descriptionReport) {
        this.descriptionReport = descriptionReport;
    }

    public String getUrlReport() {
        return urlReport;
    }

    public void setUrlReport(String urlReport) {
        this.urlReport = urlReport;
    }

}
