
package com.metiersdb.data;



/**
 *  metiersDB.Inter
 *  09/18/2012 17:49:53
 * 
 */
public class Inter {

    private InterId id;

    public InterId getId() {
        return id;
    }

    public void setId(InterId id) {
        this.id = id;
    }

}
