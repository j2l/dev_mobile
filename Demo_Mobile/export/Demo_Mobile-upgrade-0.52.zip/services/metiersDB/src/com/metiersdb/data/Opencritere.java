
package com.metiersdb.data;



/**
 *  metiersDB.Opencritere
 *  09/18/2012 17:49:53
 * 
 */
public class Opencritere {

    private OpencritereId id;

    public OpencritereId getId() {
        return id;
    }

    public void setId(OpencritereId id) {
        this.id = id;
    }

}
