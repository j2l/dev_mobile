
package com.metiersdb.data;



/**
 *  metiersDB.Opensource
 *  09/18/2012 17:49:53
 * 
 */
public class Opensource {

    private OpensourceId id;

    public OpensourceId getId() {
        return id;
    }

    public void setId(OpensourceId id) {
        this.id = id;
    }

}
