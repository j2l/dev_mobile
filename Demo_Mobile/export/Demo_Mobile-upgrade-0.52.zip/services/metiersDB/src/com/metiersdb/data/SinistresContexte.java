
package com.metiersdb.data;



/**
 *  metiersDB.SinistresContexte
 *  09/18/2012 17:49:53
 * 
 */
public class SinistresContexte {

    private SinistresContexteId id;

    public SinistresContexteId getId() {
        return id;
    }

    public void setId(SinistresContexteId id) {
        this.id = id;
    }

}
