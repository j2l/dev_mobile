
package com.metiersdb.data;



/**
 *  metiersDB.Te
 *  09/18/2012 17:49:53
 * 
 */
public class Te {

    private TeId id;

    public TeId getId() {
        return id;
    }

    public void setId(TeId id) {
        this.id = id;
    }

}
