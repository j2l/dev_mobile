
package com.metiersdb.data;



/**
 *  metiersDB.RefProduits
 *  09/18/2012 17:49:53
 * 
 */
public class RefProduits {

    private RefProduitsId id;

    public RefProduitsId getId() {
        return id;
    }

    public void setId(RefProduitsId id) {
        this.id = id;
    }

}
