
package com.metiersdb.data;



/**
 *  metiersDB.RefTransac
 *  09/18/2012 17:49:53
 * 
 */
public class RefTransac {

    private RefTransacId id;

    public RefTransacId getId() {
        return id;
    }

    public void setId(RefTransacId id) {
        this.id = id;
    }

}
