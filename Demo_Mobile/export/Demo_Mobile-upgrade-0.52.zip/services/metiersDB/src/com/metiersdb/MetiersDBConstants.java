
package com.metiersdb;



/**
 *  Query names for service "metiersDB"
 *  09/18/2012 17:50:45
 * 
 */
public class MetiersDBConstants {

    public final static String getClientsByIdQueryName = "getClientsById";

}
