
package com.metiersdb.data;



/**
 *  metiersDB.Cre
 *  09/18/2012 17:49:53
 * 
 */
public class Cre {

    private CreId id;

    public CreId getId() {
        return id;
    }

    public void setId(CreId id) {
        this.id = id;
    }

}
