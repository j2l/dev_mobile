{
	"dataNavigator1": {
		"_classes": {
			"domNode": []
		}
	},
	"dojoGrid1": {
		"_classes": {
			"domNode": []
		},
		"localizationStructure": {
			"PHONE COLUMN": "Contacts",
			"birthday": "Birthday",
			"id": "Id",
			"name.familyName": "FamilyName",
			"name.formatted": "Formatted",
			"name.givenName": "GivenName",
			"name.honorificPrefix": "HonorificPrefix",
			"name.honorificSuffix": "HonorificSuffix",
			"name.middleName": "MiddleName",
			"nickname": "Nickname",
			"note": "Note"
		},
		"primaryKeyFields": ["id"]
	},
	"layoutBox1": {
		"_classes": {
			"domNode": []
		}
	}
}