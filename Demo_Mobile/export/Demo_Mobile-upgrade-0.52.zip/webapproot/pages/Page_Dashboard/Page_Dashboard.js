dojo.declare("Page_Dashboard", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	_end: 0
});