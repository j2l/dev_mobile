dojo.declare("Page_Mobile", wm.Page, {
	"preferredDevice": "phone",
	start: function() {
		
	},

	_end: 0
});