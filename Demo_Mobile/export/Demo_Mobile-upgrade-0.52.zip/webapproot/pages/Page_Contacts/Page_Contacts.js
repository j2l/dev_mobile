dojo.declare("Page_Contacts", wm.Page, {
	"i18n": true,
	"preferredDevice": "desktop",
	start: function() {
		
	},

	_end: 0
});