dojo.declare("Page_Client", wm.Page, {
	"preferredDevice": "tablet",
	start: function() {
		
	},

	_end: 0
});