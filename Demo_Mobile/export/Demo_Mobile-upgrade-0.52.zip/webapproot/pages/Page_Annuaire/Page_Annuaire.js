dojo.declare("Page_Annuaire", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	_end: 0
});