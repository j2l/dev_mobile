Custom java classes can be added to this folder using package names. Files added to this folder will be copied to WEB-INF for deployment.
